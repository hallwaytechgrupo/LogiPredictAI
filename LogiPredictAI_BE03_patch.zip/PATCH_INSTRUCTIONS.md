# Patch BE-03 — LogiPredictAI

Este patch adiciona a classificação demonstrativa por regras ao backend Node.js sem substituir a integração atual com o serviço Python/Random Forest.

## Arquivos incluídos

- `back/src/app.js` — atualizado: registra `POST /predict` na API Express.
- `back/src/risk-rules.js` — novo: valida os campos e calcula a pontuação por regras.
- `back/test/predict_rules_api.test.js` — novo: testes HTTP do endpoint.
- `docs/risk-rules.md` — novo: contrato, regras, exemplos e limitações.
- `docs/api.md` — atualizado: documenta a nova rota.
- `back/README.md` — atualizado: diferencia a BE-03 da previsão por ML.

## Aplicação

1. Faça backup do projeto ou crie uma branch de trabalho.
2. Extraia o conteúdo deste ZIP na raiz do repositório, mantendo as pastas.
3. Permita substituir `back/src/app.js`, `docs/api.md` e `back/README.md`.
4. Confira o diff antes de executar os testes.

## Branch recomendada

No repositório atual, use uma branch criada a partir da `main`:

```powershell
git switch main
git pull --ff-only origin main
git switch -c feat/be-03-predict-rules
```

Não use a branch remota `back` sem alinhamento da equipe: ela possui outra estrutura de diretórios (`api`, `ml`, `scripts` na raiz) e não corresponde ao layout integrado na `main` (`back/src`, `back/ml`, `flutter_app`).

## Instalar dependências e testar

```powershell
cd back
npm.cmd ci
npm.cmd test
```

Os testes novos usam `node:test` e iniciam a API em uma porta temporária. O teste do `POST /predict` usa uma URL ML deliberadamente indisponível para comprovar que a rota de regras não depende do serviço Python.

## Executar e testar manualmente

Em `back`:

```powershell
npm.cmd run dev
```

Em outro PowerShell:

```powershell
$body = @{
  package_weight_kg = 10
  distance_km = 300
  available_days = 3
} | ConvertTo-Json

Invoke-RestMethod `
  -Uri "http://127.0.0.1:3001/predict" `
  -Method Post `
  -ContentType "application/json" `
  -Body $body
```

Resposta esperada: `risk_score = 3`, `risk_level = "medio"` e `risk_label = "Médio"`.

Para testar uma entrada inválida:

```powershell
$body = @{
  package_weight_kg = -1
  distance_km = 300
  available_days = 3
} | ConvertTo-Json

try {
  Invoke-RestMethod `
    -Uri "http://127.0.0.1:3001/predict" `
    -Method Post `
    -ContentType "application/json" `
    -Body $body
} catch {
  $_.ErrorDetails.Message
}
```

Resultado esperado: HTTP 422 com `error = "VALIDATION_ERROR"` e detalhes do campo inválido.

## Limites conhecidos

Os cortes são demonstrativos, não foram calibrados com a Olist. A resposta não é probabilidade de atraso. A rota não persiste dados e não altera `POST /api/v1/predictions`, que continua encaminhando pedidos ao modelo Python.
