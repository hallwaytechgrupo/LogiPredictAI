/**
 * Classificação demonstrativa de risco de atraso (BE-03).
 *
 * Esta regra não utiliza o serviço Python nem o modelo Random Forest.
 * Os limites são heurísticos e servem somente para demonstrar o fluxo da API.
 */

const MAX_WEIGHT_KG = 1000;
const MAX_DISTANCE_KM = 20050;
const MAX_AVAILABLE_DAYS = 365;

const REQUIRED_FIELDS = [
  'package_weight_kg',
  'distance_km',
  'available_days',
];

/**
 * Valida o contrato recebido por POST /predict.
 *
 * Aceita somente números JSON finitos e os três campos definidos no contrato.
 * Retorna os dados normalizados ou uma lista de erros por campo.
 */
export function validateRuleBasedPrediction(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    return {
      value: null,
      errors: [{ field: 'body', message: 'O corpo deve ser um objeto JSON.' }],
    };
  }

  const errors = [];
  const allowedFields = new Set(REQUIRED_FIELDS);

  for (const field of Object.keys(body)) {
    if (!allowedFields.has(field)) {
      errors.push({
        field,
        message: 'Campo não permitido neste endpoint.',
      });
    }
  }

  const limits = {
    package_weight_kg: {
      min: 0,
      max: MAX_WEIGHT_KG,
      minExclusive: true,
      message: `Deve ser maior que 0 e menor ou igual a ${MAX_WEIGHT_KG} kg.`,
    },
    distance_km: {
      min: 0,
      max: MAX_DISTANCE_KM,
      minExclusive: false,
      message: `Deve estar entre 0 e ${MAX_DISTANCE_KM} km.`,
    },
    available_days: {
      min: 0,
      max: MAX_AVAILABLE_DAYS,
      minExclusive: false,
      message: `Deve estar entre 0 e ${MAX_AVAILABLE_DAYS} dias.`,
    },
  };

  for (const field of REQUIRED_FIELDS) {
    if (!Object.hasOwn(body, field)) {
      errors.push({ field, message: 'Campo obrigatório.' });
      continue;
    }

    const value = body[field];
    const limit = limits[field];

    if (typeof value !== 'number' || !Number.isFinite(value)) {
      errors.push({
        field,
        message: 'Informe um número JSON válido, sem aspas.',
      });
      continue;
    }

    const belowMinimum = limit.minExclusive
      ? value <= limit.min
      : value < limit.min;

    if (belowMinimum || value > limit.max) {
      errors.push({ field, message: limit.message });
    }
  }

  if (errors.length > 0) {
    return { value: null, errors };
  }

  return {
    value: {
      package_weight_kg: body.package_weight_kg,
      distance_km: body.distance_km,
      available_days: body.available_days,
    },
    errors: [],
  };
}

/**
 * Calcula uma pontuação heurística de 0 a 6 e classifica o risco.
 *
 * Cada dimensão contribui com:
 * 0 pontos = condição favorável;
 * 1 ponto  = condição intermediária;
 * 2 pontos = condição desfavorável.
 */
export function classifyRuleBasedRisk(input) {
  const weight = input.package_weight_kg;
  const distance = input.distance_km;
  const availableDays = input.available_days;

  const factors = [
    {
      field: 'package_weight_kg',
      value: weight,
      unit: 'kg',
      points: weight <= 5 ? 0 : weight <= 20 ? 1 : 2,
      rule: weight <= 5
        ? 'Peso de até 5 kg.'
        : weight <= 20
          ? 'Peso acima de 5 kg e até 20 kg.'
          : 'Peso acima de 20 kg.',
    },
    {
      field: 'distance_km',
      value: distance,
      unit: 'km',
      points: distance <= 100 ? 0 : distance <= 500 ? 1 : 2,
      rule: distance <= 100
        ? 'Distância de até 100 km.'
        : distance <= 500
          ? 'Distância acima de 100 km e até 500 km.'
          : 'Distância acima de 500 km.',
    },
    {
      field: 'available_days',
      value: availableDays,
      unit: 'dias',
      points: availableDays >= 5 ? 0 : availableDays >= 2 ? 1 : 2,
      rule: availableDays >= 5
        ? 'Prazo disponível de pelo menos 5 dias.'
        : availableDays >= 2
          ? 'Prazo disponível de 2 a menos de 5 dias.'
          : 'Prazo disponível inferior a 2 dias.',
    },
  ];

  const riskScore = factors.reduce((total, factor) => total + factor.points, 0);

  let riskLevel;
  let riskLabel;

  if (riskScore <= 1) {
    riskLevel = 'baixo';
    riskLabel = 'Baixo';
  } else if (riskScore <= 3) {
    riskLevel = 'medio';
    riskLabel = 'Médio';
  } else {
    riskLevel = 'alto';
    riskLabel = 'Alto';
  }

  return {
    method: 'rule_based_demo_v1',
    is_demonstration: true,
    risk_score: riskScore,
    max_score: 6,
    risk_level: riskLevel,
    risk_label: riskLabel,
    input,
    factors,
    message: 'Classificação demonstrativa por regras fixas. Não representa uma probabilidade de atraso nem utiliza Machine Learning.',
  };
}
