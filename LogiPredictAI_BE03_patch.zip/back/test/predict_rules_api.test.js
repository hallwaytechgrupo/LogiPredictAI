import test from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../src/app.js';

async function makeApi(t) {
  // A porta 1 não terá serviço ML. POST /predict deve funcionar sem chamá-lo.
  const server = createApp({ mlUrl: 'http://127.0.0.1:1' }).listen(0);
  await new Promise((resolve) => server.once('listening', resolve));

  t.after(async () => {
    await new Promise((resolve, reject) => {
      server.close((error) => error ? reject(error) : resolve());
    });
  });

  return `http://127.0.0.1:${server.address().port}`;
}

async function predict(baseUrl, body, headers = { 'Content-Type': 'application/json' }) {
  return fetch(`${baseUrl}/predict`, {
    method: 'POST',
    headers,
    body: JSON.stringify(body),
  });
}

test('POST /predict classifies low, medium and high risk using demonstration rules', async (t) => {
  const baseUrl = await makeApi(t);
  const cases = [
    {
      input: { package_weight_kg: 2.5, distance_km: 80, available_days: 7 },
      expectedScore: 0,
      expectedLevel: 'baixo',
      expectedLabel: 'Baixo',
    },
    {
      input: { package_weight_kg: 10, distance_km: 300, available_days: 3 },
      expectedScore: 3,
      expectedLevel: 'medio',
      expectedLabel: 'Médio',
    },
    {
      input: { package_weight_kg: 30, distance_km: 800, available_days: 1 },
      expectedScore: 6,
      expectedLevel: 'alto',
      expectedLabel: 'Alto',
    },
  ];

  for (const scenario of cases) {
    const response = await predict(baseUrl, scenario.input);
    assert.equal(response.status, 200);

    const result = await response.json();
    assert.equal(result.method, 'rule_based_demo_v1');
    assert.equal(result.is_demonstration, true);
    assert.equal(result.risk_score, scenario.expectedScore);
    assert.equal(result.max_score, 6);
    assert.equal(result.risk_level, scenario.expectedLevel);
    assert.equal(result.risk_label, scenario.expectedLabel);
    assert.equal(result.factors.length, 3);
    assert.deepEqual(result.input, scenario.input);
    assert.match(result.message, /não representa uma probabilidade/i);
  }
});

test('POST /predict validates required fields, types, ranges and unknown fields', async (t) => {
  const baseUrl = await makeApi(t);
  const invalidInputs = [
    {},
    { package_weight_kg: '2.5', distance_km: 80, available_days: 7 },
    { package_weight_kg: -1, distance_km: 80, available_days: 7 },
    { package_weight_kg: 2.5, distance_km: 20051, available_days: 7 },
    { package_weight_kg: 2.5, distance_km: 80, available_days: 366 },
    { package_weight_kg: 2.5, distance_km: 80, available_days: 7, extra: true },
    [],
  ];

  for (const input of invalidInputs) {
    const response = await predict(baseUrl, input);
    assert.equal(response.status, 422);
    const result = await response.json();
    assert.equal(result.error, 'VALIDATION_ERROR');
    assert.ok(Array.isArray(result.details));
    assert.ok(result.details.length > 0);
  }
});

test('POST /predict rejects requests without application/json', async (t) => {
  const baseUrl = await makeApi(t);
  const response = await fetch(`${baseUrl}/predict`, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain' },
    body: 'not-json',
  });

  assert.equal(response.status, 415);
  assert.equal((await response.json()).error, 'UNSUPPORTED_MEDIA_TYPE');
});

test('POST /predict does not depend on the Python ML service', async (t) => {
  const baseUrl = await makeApi(t);
  const response = await predict(baseUrl, {
    package_weight_kg: 2.5,
    distance_km: 80,
    available_days: 7,
  });

  assert.equal(response.status, 200);
  assert.equal((await response.json()).method, 'rule_based_demo_v1');
});

test('POST /predict applies the documented classification boundaries', async (t) => {
  const baseUrl = await makeApi(t);
  const cases = [
    { input: { package_weight_kg: 5, distance_km: 100, available_days: 3 }, score: 1, level: 'baixo' },
    { input: { package_weight_kg: 10, distance_km: 100, available_days: 3 }, score: 2, level: 'medio' },
    { input: { package_weight_kg: 30, distance_km: 300, available_days: 3 }, score: 4, level: 'alto' },
  ];

  for (const scenario of cases) {
    const response = await predict(baseUrl, scenario.input);
    assert.equal(response.status, 200);
    const result = await response.json();
    assert.equal(result.risk_score, scenario.score);
    assert.equal(result.risk_level, scenario.level);
  }
});
