# BE-03 — Classificação demonstrativa por regras

## Objetivo e escopo

O endpoint `POST /predict` da API Node.js demonstra o fluxo de recebimento, validação e classificação de risco de atraso usando regras fixas.

Esta implementação:
- recebe peso do pacote, distância e prazo disponível;
- valida os três valores;
- calcula uma pontuação heurística;
- retorna `Baixo`, `Médio` ou `Alto` em JSON.

**Não utiliza Machine Learning, não chama o serviço Python e não produz probabilidade de atraso.** Os limites abaixo são parâmetros didáticos iniciais, não foram aprendidos com a base Olist nem validados em uma operação logística.

## Contrato

- Método: `POST`
- Rota: `/predict`
- Serviço: API Node.js
- URL local: `http://127.0.0.1:3001/predict`
- Content-Type: `application/json`

### Entrada

```json
{
  "package_weight_kg": 10,
  "distance_km": 300,
  "available_days": 3
}
```

| Campo | Tipo | Unidade | Validação |
| --- | --- | --- | --- |
| `package_weight_kg` | number | kg | Maior que 0 e até 1.000 |
| `distance_km` | number | km | De 0 até 20.050 |
| `available_days` | number | dias | De 0 até 365 |

Os três campos são obrigatórios. Os valores devem ser números JSON, não strings. Campos adicionais são rejeitados.

`available_days` representa a quantidade de dias restantes para cumprir o prazo no momento da análise. Zero é aceito e representa prazo sem dias restantes.

### Regras de pontuação

Cada dimensão adiciona de 0 a 2 pontos:

| Dimensão | Condição | Pontos |
| --- | --- | ---: |
| Peso | Até 5 kg | 0 |
| Peso | Acima de 5 kg e até 20 kg | 1 |
| Peso | Acima de 20 kg | 2 |
| Distância | Até 100 km | 0 |
| Distância | Acima de 100 km e até 500 km | 1 |
| Distância | Acima de 500 km | 2 |
| Prazo disponível | 5 dias ou mais | 0 |
| Prazo disponível | De 2 a menos de 5 dias | 1 |
| Prazo disponível | Menos de 2 dias | 2 |

A pontuação total varia de 0 a 6:

| Pontuação | Classificação |
| ---: | --- |
| 0–1 | Baixo |
| 2–3 | Médio |
| 4–6 | Alto |

As três dimensões têm o mesmo peso. A resposta também informa os pontos e a regra aplicada a cada dimensão para tornar a decisão demonstrável.

### Exemplo de resposta

Para a entrada de 10 kg, 300 km e 3 dias, cada dimensão adiciona 1 ponto; total de 3 pontos:

```json
{
  "method": "rule_based_demo_v1",
  "is_demonstration": true,
  "risk_score": 3,
  "max_score": 6,
  "risk_level": "medio",
  "risk_label": "Médio",
  "input": {
    "package_weight_kg": 10,
    "distance_km": 300,
    "available_days": 3
  },
  "factors": [
    {
      "field": "package_weight_kg",
      "value": 10,
      "unit": "kg",
      "points": 1,
      "rule": "Peso acima de 5 kg e até 20 kg."
    },
    {
      "field": "distance_km",
      "value": 300,
      "unit": "km",
      "points": 1,
      "rule": "Distância acima de 100 km e até 500 km."
    },
    {
      "field": "available_days",
      "value": 3,
      "unit": "dias",
      "points": 1,
      "rule": "Prazo disponível de 2 a menos de 5 dias."
    }
  ],
  "message": "Classificação demonstrativa por regras fixas. Não representa uma probabilidade de atraso nem utiliza Machine Learning."
}
```

### Erros

| HTTP | Situação |
| ---: | --- |
| 200 | Entrada válida e classificação calculada |
| 400 | JSON malformado |
| 413 | Corpo maior que o limite global da API |
| 415 | Content-Type diferente de `application/json` |
| 422 | Campo ausente, tipo incorreto, valor fora dos limites ou campo desconhecido |

Exemplo de chamada PowerShell:

```powershell
$body = @{
  package_weight_kg = 10
  distance_km = 300
  available_days = 3
} | ConvertTo-Json

Invoke-RestMethod `
  -Uri "http://127.0.0.1:3001/predict" `
  -Method Post `
  -ContentType "application/json" `
  -Body $body
```

## Limitações

1. Os limites são heurísticos e demonstrativos; não foram estimados a partir dos dados Olist.
2. Peso e distância não determinam sozinhos o atraso. Modal, transportadora, rota, trânsito, clima, capacidade operacional, origem/destino e eventos de rastreamento não são considerados.
3. O score de 0 a 6 é uma soma de pontos, não uma porcentagem nem uma probabilidade estatística.
4. O endpoint classifica um pacote simplificado. O modelo atual do projeto trabalha com agregados por pedido; não se deve assumir equivalência automática entre pacote e pedido.
5. Não há persistência do resultado nesta tarefa.
6. Os limites precisam ser revistos com a equipe e validados com dados operacionais antes de qualquer uso real.

## Relação com a previsão de Machine Learning existente

Há dois fluxos distintos, que não devem ser confundidos:

- `POST http://127.0.0.1:3001/predict`: endpoint BE-03, regras fixas, sem ML.
- `POST http://127.0.0.1:3001/api/v1/predictions`: endpoint já existente, encaminha a solicitação à API Python e pode persistir o resultado quando recebe `order_id`.
- `POST http://127.0.0.1:8000/predict`: endpoint interno FastAPI que utiliza o modelo Random Forest carregado.

O endpoint BE-03 não altera nem substitui os fluxos de Machine Learning existentes. A interface Flutter atual continua consumindo `/api/v1/predictions`; a integração visual com o novo endpoint é uma atividade separada.
